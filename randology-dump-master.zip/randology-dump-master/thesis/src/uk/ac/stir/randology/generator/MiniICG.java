package uk.ac.stir.randology.generator;

public class MiniICG extends ICG {
	public MiniICG(long seed) {
		super("MiniICG",61,2,256,seed);
	}
}

// 6075,106,1283