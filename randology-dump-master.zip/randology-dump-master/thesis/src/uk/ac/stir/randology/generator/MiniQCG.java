package uk.ac.stir.randology.generator;

public class MiniQCG extends QCG {
	public MiniQCG(long seed) {
		super("MiniQCG",62,1,256,seed);
	}
}