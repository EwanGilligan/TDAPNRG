package uk.ac.stir.randology.generator;

public class MiniEICG extends ICG {
	public MiniEICG(long seed) {
		super("MiniICG",61,2,127,seed);
	}
}

// 6075,106,1283